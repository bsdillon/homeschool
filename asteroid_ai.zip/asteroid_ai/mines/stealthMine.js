class StealthMine extends StandardMine {
    constructor(x, y, name = "Stealth", color = "#222222", triggerDistance = 10, callback = null) {
        super(x, y, name, color, triggerDistance, callback);
    }
}